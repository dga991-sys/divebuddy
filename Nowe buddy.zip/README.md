# DiveBuddy

Gotowa statyczna aplikacja do wdrożenia na Vercel.

Pliki:
- index.html
- styles.css
- app.js
- vercel.json

Aplikacja jest połączona z projektem Supabase `nrxuvdkoacfycbvursne`.
Obsługuje rejestrację, logowanie i profil nurka.
