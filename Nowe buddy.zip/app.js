
const SUPABASE_URL = "https://nrxuvdkoacfycbvursne.supabase.co";
const SUPABASE_KEY = "sb_publishable_R_ADJ7kHEy8CKA_1PziPhQ_XP4nThe4";

const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const authView = document.getElementById("authView");
const profileView = document.getElementById("profileView");
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const authMessage = document.getElementById("authMessage");
const profileForm = document.getElementById("profileForm");
const profileMessage = document.getElementById("profileMessage");

function setMessage(el, text, type="") {
  el.textContent = text || "";
  el.className = "message" + (type ? " " + type : "");
}

function showLogin() {
  loginForm.classList.remove("hidden");
  registerForm.classList.add("hidden");
  loginTab.classList.add("active");
  registerTab.classList.remove("active");
  setMessage(authMessage, "");
}

function showRegister() {
  registerForm.classList.remove("hidden");
  loginForm.classList.add("hidden");
  registerTab.classList.add("active");
  loginTab.classList.remove("active");
  setMessage(authMessage, "");
}

loginTab.addEventListener("click", showLogin);
registerTab.addEventListener("click", showRegister);

async function upsertProfile(user, nameIfNew = null) {
  const { data: current } = await sb.from("profiles").select("*").eq("id", user.id).maybeSingle();
  if (current) return current;

  const displayName = nameIfNew || user.user_metadata?.display_name || user.email?.split("@")[0] || "Nurek";
  const { data, error } = await sb.from("profiles")
    .insert({ id: user.id, display_name: displayName })
    .select()
    .single();
  if (error) throw error;
  return data;
}

async function loadProfile(user, nameIfNew = null) {
  authView.classList.add("hidden");
  profileView.classList.remove("hidden");
  document.getElementById("profileEmail").textContent = user.email || "";

  try {
    const p = await upsertProfile(user, nameIfNew);
    document.getElementById("profileTitle").textContent = p.display_name || "Profil";
    document.getElementById("displayName").value = p.display_name || "";
    document.getElementById("country").value = p.country || "Polska";
    document.getElementById("city").value = p.city || "";
    document.getElementById("language").value = p.language || "Polski";
    document.getElementById("certificationOrg").value = p.certification_org || "CMAS";
    document.getElementById("certificationLevel").value = p.certification_level || "P1";
    document.getElementById("divesCount").value = p.dives_count ?? 0;
    document.getElementById("maxDepth").value = p.max_depth_m ?? 0;
    document.getElementById("lastDiveDate").value = p.last_dive_date || "";
  } catch (e) {
    setMessage(profileMessage, "Nie udało się wczytać profilu: " + (e.message || e), "error");
  }
}

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setMessage(authMessage, "Logowanie...");
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;

  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) return setMessage(authMessage, error.message, "error");
  await loadProfile(data.user);
});

registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setMessage(authMessage, "Tworzenie konta...");
  const display_name = document.getElementById("registerName").value.trim();
  const email = document.getElementById("registerEmail").value.trim();
  const password = document.getElementById("registerPassword").value;

  const { data, error } = await sb.auth.signUp({
    email,
    password,
    options: { data: { display_name } }
  });
  if (error) return setMessage(authMessage, error.message, "error");

  if (!data.session) {
    setMessage(authMessage, "Konto utworzone. Sprawdź e-mail i potwierdź rejestrację, a potem się zaloguj.", "success");
    showLogin();
    return;
  }

  await loadProfile(data.user, display_name);
});

profileForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setMessage(profileMessage, "Zapisywanie...");

  const { data: userData } = await sb.auth.getUser();
  const user = userData.user;
  if (!user) return setMessage(profileMessage, "Sesja wygasła. Zaloguj się ponownie.", "error");

  const payload = {
    id: user.id,
    display_name: document.getElementById("displayName").value.trim(),
    city: document.getElementById("city").value.trim() || null,
    country: document.getElementById("country").value.trim() || "Polska",
    language: document.getElementById("language").value,
    certification_org: document.getElementById("certificationOrg").value,
    certification_level: document.getElementById("certificationLevel").value.trim() || null,
    dives_count: Number(document.getElementById("divesCount").value || 0),
    max_depth_m: Number(document.getElementById("maxDepth").value || 0),
    last_dive_date: document.getElementById("lastDiveDate").value || null,
    updated_at: new Date().toISOString()
  };

  const { data, error } = await sb.from("profiles").upsert(payload).select().single();
  if (error) return setMessage(profileMessage, error.message, "error");

  document.getElementById("profileTitle").textContent = data.display_name || "Profil";
  setMessage(profileMessage, "Profil zapisany.", "success");
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  await sb.auth.signOut();
  profileView.classList.add("hidden");
  authView.classList.remove("hidden");
  showLogin();
});

(async function boot() {
  const { data } = await sb.auth.getSession();
  if (data.session?.user) await loadProfile(data.session.user);
})();
